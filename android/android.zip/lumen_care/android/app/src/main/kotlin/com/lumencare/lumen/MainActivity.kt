package com.lumencare.lumen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
